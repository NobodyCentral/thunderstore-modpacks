## Description
Just a small modpack for me and my friends.

## Mods
NoRainDamage by JoelOliMclean
Transmog by Alpus
TrashItems by VirtuaCode
AzuCraftyBoxes by Azumatt
UnlimitedFuel by rendl0449
SaveCrossbowState by Azumatt